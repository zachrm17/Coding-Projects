package bean;

public class Merchandise {
	private int  item_price;
	private String item_image, item_id;

	public String getId() {
		return item_id;
	}

	public void setId(String item_id) {
		this.item_id = item_id;
	}

	public int getPrice() {
		return item_price;
	}
	
	public void setPrice(int item_price) {
		this.item_price = item_price;
	}
	
	public String getImage() {
		return item_image;
	}
	
	public void setImage(String item_image) {
		this.item_image = item_image;
	}

	/*public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}
*/
}
