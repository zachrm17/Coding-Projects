package bean;

public class MarvelCharacters {
	private int id;
	private String charName, speakingDay, speakingTime, roomNum, movies, characterImage;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getcharName() {
		return charName;
	}

	public void setcharName(String charName) {
		this.charName = charName;
	}

	public String getspeakingDay() {
		return speakingDay;
	}

	public void setspeakingDay(String speakingDay) {
		this.speakingDay = speakingDay;
	}

	public String getspeakingTime() {
		return speakingTime;
	}

	public void setspeakingTime(String speakingTime) {
		this.speakingTime = speakingTime;
	}

	public String getmovies() {
		return movies;
	}

	public void setmovies(String movies) {
		this.movies = movies;
	}
	
	public void setroomNum(String roomNum) {
		this.roomNum = roomNum;
	}
	
	public String getroomNum() {
		return roomNum;
	}

	public void roomNum(String roomNum) {
		this.roomNum = roomNum;
	}
	
	public void setcharacterImage(String characterImage) {
		this.characterImage = characterImage;
	}
	
	public String getcharacterImage() {
		return characterImage;
	}
	
	public void characterImage(String characterImage) {
		this.characterImage = characterImage;
	}
}
