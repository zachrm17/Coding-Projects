package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import bean.User;

public class UserDao {
	
public static Connection getConnection(){
	Connection con=null;
	try{
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost/marvelconventiondatabase?useSSL=false", "root", "sesame");
	}catch(Exception e){System.out.println(e);}
	return con;
}

public static int save(User u){
	int status=0;
	Connection con=getConnection();

	try{
		PreparedStatement ps=con.prepareStatement("insert into registrant(name,password,email,permission) values(?,?,?,?)");
		ps.setString(1,u.getName());
		ps.setString(2,u.getPassword());
		ps.setString(3,u.getEmail());
		ps.setString(4,u.getPermission());
		status=ps.executeUpdate();
		ps.close();
	}catch(Exception e){System.out.println(e);}
	finally{
		if(con!=null) {
			 try { con.close(); } catch (Exception ex) { }
		}
	}
	return status;
}

public static int update(User u){
	int status=0;
	Connection con=getConnection();

	try{
		PreparedStatement ps=con.prepareStatement("update registrant set name=?,password=?,email=?,permission=? where id=?");
		ps.setString(1,u.getName());
		ps.setString(2,u.getPassword());
		ps.setString(3,u.getEmail());
		ps.setString(4,u.getPermission());
		ps.setInt(5,u.getId());
		status=ps.executeUpdate();
		ps.close();
	}catch(Exception e){System.out.println(e);}
	finally{
		if(con!=null) {
			 try { con.close(); } catch (Exception ex) { }
		}
	}
	return status;
}

public static int delete(User u){
	int status=0;
	Connection con=getConnection();

	try{
		PreparedStatement ps=con.prepareStatement("delete from registrant where id=?");
		ps.setInt(1,u.getId());
		status=ps.executeUpdate();
		ps.close();
	}catch(Exception e){System.out.println(e);}
	finally{
		if(con!=null) {
			 try { con.close(); } catch (Exception ex) { }
		}
	}
	return status;
}

public static List<User> getAllRecords(){
	List<User> list=new ArrayList<User>();
	Connection con=getConnection();

	try{
		PreparedStatement ps=con.prepareStatement("select * from registrant");
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			User u=new User();
			u.setId(rs.getInt("id"));
			u.setName(rs.getString("name"));
			u.setPassword(rs.getString("password"));
			u.setEmail(rs.getString("email"));
			u.setPermission(rs.getString("permission"));
			list.add(u);
		}
		ps.close();
		rs.close();
	}catch(Exception e){System.out.println(e);}
	finally{
		if(con!=null) {
			 try { con.close(); } catch (Exception ex) { }
		}
	}
	return list;
}

public static User getRecordById(int id){
	User u=null;
	Connection con=getConnection();

	try{
		PreparedStatement ps=con.prepareStatement("select * from registrant where id=?");
		ps.setInt(1,id);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			u=new User();
			u.setId(rs.getInt("id"));
			u.setName(rs.getString("name"));
			u.setPassword(rs.getString("password"));
			u.setEmail(rs.getString("email"));
			u.setPermission(rs.getString("permission"));
		}
		ps.close();
		rs.close();
	}catch(Exception e){System.out.println(e);}
	finally{
		if(con!=null) {
			 try { con.close(); } catch (Exception ex) { }
		}
	}
	return u;
}

public static List<User> getRecordByName(String name) {
	List<User> list=new ArrayList<User>();
	Connection con=getConnection();

	try{
		PreparedStatement ps=con.prepareStatement("select * from registrant where name=?");
		ps.setString(1,name);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			User u=new User();
			u.setId(rs.getInt("id"));
			u.setName(rs.getString("name"));
			u.setPassword(rs.getString("password"));
			u.setEmail(rs.getString("email"));
			u.setPermission(rs.getString("permission"));
			list.add(u);
		}
		ps.close();
		rs.close();
	}catch(Exception e){System.out.println(e);}
	finally{
		if(con!=null) {
			 try { con.close(); } catch (Exception ex) { }
		}
	}
	return list;
}
}
