package dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import bean.Merchandise;

public class MerchandiseDao {
	
public static Connection getConnection(){
	Connection con=null;
	try{
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost/marvelconventiondatabase?useSSL=false", "root", "sesame");
	}catch(Exception e){System.out.println(e);}
	return con;
}

public static int save(Merchandise u){
	int status=0;
	Connection con=getConnection();

	try{
		PreparedStatement ps=con.prepareStatement("insert into merchandise(item_id,item_price,item_image) values(?,?,?)");
		ps.setString(1,u.getId());
		ps.setInt(2,u.getPrice());
		ps.setString(3,u.getImage());
		status=ps.executeUpdate();
		ps.close();
	}catch(Exception e){System.out.println(e);}
	finally{
		if(con!=null) {
			 try { con.close(); } catch (Exception ex) { }
		}
	}
	return status;
}

public static int update(Merchandise u){
	int status=0;
	Connection con=getConnection();

	try{
		PreparedStatement ps=con.prepareStatement("update merchandise set item_id=?,item_price=?,item_image=?, where item_id=?");
		ps.setString(1,u.getId());
		ps.setInt(2,u.getPrice());
		ps.setString(3,u.getImage());
		status=ps.executeUpdate();
		ps.close();
	}catch(Exception e){System.out.println(e);}
	finally{
		if(con!=null) {
			 try { con.close(); } catch (Exception ex) { }
		}
	}
	return status;
}


public static List<Merchandise> getAllRecords(){
	List<Merchandise> list=new ArrayList<Merchandise>();
	Connection con=getConnection();

	try{
		PreparedStatement ps=con.prepareStatement("select * from merchandise");
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			Merchandise u=new Merchandise();
			u.setId(rs.getString("item_id"));
			u.setPrice(rs.getInt("item_price"));
			u.setImage(rs.getString("item_image"));
			list.add(u);
		}
		ps.close();
		rs.close();
	}catch(Exception e){System.out.println(e);}
	finally{
		if(con!=null) {
			 try { con.close(); } catch (Exception ex) { }
		}
	}
	return list;
}
}
