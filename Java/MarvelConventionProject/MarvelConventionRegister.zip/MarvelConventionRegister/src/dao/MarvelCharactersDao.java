package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import bean.MarvelCharacters;

public class MarvelCharactersDao {
	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/marvelconventiondatabase?useSSL=false", "root", "sesame");
		}catch(Exception e){System.out.println(e);}
		return con;
	}

	public static int save(MarvelCharacters m){
		int status=0;
		Connection con=getConnection();
		try{
			PreparedStatement ps=con.prepareStatement("insert into characters(id, charName,speakingDay,speakingTime,roomNum,movies) values(?,?,?,?,?,?)");
			ps.setInt(1,m.getId());
			ps.setString(2,m.getcharName());
			ps.setString(3,m.getspeakingDay());
			ps.setString(4,m.getspeakingTime());
			ps.setString(5,m.getroomNum());
			ps.setString(6,m.getmovies());
			status=ps.executeUpdate();
			ps.close();
		}catch(Exception e){System.out.println(e);}
		finally{
			if(con!=null) {
				 try { con.close(); } catch (Exception ex) { }
			}
		}
		return status;
	}

	public static int update(MarvelCharacters m){
		int status=0;
		Connection con=getConnection();
		try{
			PreparedStatement ps=con.prepareStatement("update characters set id=?,charName=?,speakingDay=?,speakingTime=?,roomNum=?,movies=?");
			ps.setInt(1,m.getId());
			ps.setString(2,m.getcharName());
			ps.setString(3,m.getspeakingDay());
			ps.setString(4,m.getspeakingTime());
			ps.setString(5,m.getroomNum());
			ps.setString(6,m.getmovies());
			status=ps.executeUpdate();
			ps.close();
		}catch(Exception e){System.out.println(e);}
		finally{
			if(con!=null) {
				 try { con.close(); } catch (Exception ex) { }
			}
		}
		return status;
	}

	public static int delete(MarvelCharacters m){
		int status=0;
		Connection con=getConnection();

		try{
			PreparedStatement ps=con.prepareStatement("delete from characters where id=?");
			ps.setInt(1,m.getId());
			status=ps.executeUpdate();
			ps.close();
		}catch(Exception e){System.out.println(e);}
		finally{
			if(con!=null) {
				 try { con.close(); } catch (Exception ex) { }
			}
		}

		return status;
	}
	public static List<MarvelCharacters> getAllRecords(){
		List<MarvelCharacters> list=new ArrayList<MarvelCharacters>();
		Connection con=getConnection();

		try{
			PreparedStatement ps=con.prepareStatement("select * from characters");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				MarvelCharacters m=new MarvelCharacters();
				m.setId(rs.getInt("id"));
				m.setcharName(rs.getString("charName"));
				m.setspeakingDay(rs.getString("speakingDay"));
				m.setspeakingTime(rs.getString("speakingTime"));
				m.setroomNum(rs.getString("roomNum"));
				m.setmovies(rs.getString("movies"));
				list.add(m);
			}
			ps.close();
			rs.close();
		}catch(Exception e){System.out.println(e);}
		finally{
			if(con!=null) {
				 try { con.close(); } catch (Exception ex) { }
			}
		}
		return list;
	}
	public static MarvelCharacters getRecordById(int id){
		MarvelCharacters m=null;
		Connection con=getConnection();

		try{
			PreparedStatement ps=con.prepareStatement("select * from characters where id=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				m=new MarvelCharacters();
				m.setId(rs.getInt("id"));
				m.setcharName(rs.getString("charName"));
				m.setspeakingDay(rs.getString("speakingDay"));
				m.setspeakingTime(rs.getString("speakingTime"));
				m.setroomNum(rs.getString("roomNum"));
				m.setmovies(rs.getString("movies"));
				m.setcharacterImage(rs.getString("characterImage"));
			}
			ps.close();
			rs.close();
		}catch(Exception e){System.out.println(e);}
		finally{
			if(con!=null) {
				 try { con.close(); } catch (Exception ex) { }
			}
		}
		return m;
	}
	
	public static int registerCharacter(int userId, int eventId) {
		int status=0;
		Connection con=getConnection();

		try{
			PreparedStatement ps1=con.prepareStatement("select * from registered_events where id=?");
			ps1.setString(1, Integer.toString(userId));
			ResultSet rs=ps1.executeQuery();
			while(rs.next()){
				if(rs.getInt("eventid") == eventId) {
					ps1.close();
					rs.close();
					return -1;
				}
			}
			
			PreparedStatement ps2=con.prepareStatement("insert into registered_events(id, eventid) values(?,?)");
			ps2.setString(1,Integer.toString(userId));
			ps2.setString(2,Integer.toString(eventId));
			status=ps2.executeUpdate();
			ps1.close();
			rs.close();
			ps2.close();
		}catch(Exception e){System.out.println(e);}
		finally{
			if(con!=null) {
				 try { con.close(); } catch (Exception ex) { }
			}
		}
		return status;
	}
	
	public static int unregisterCharacter(int userId, MarvelCharacters m) {
		int status=0;
		Connection con=getConnection();

		try{
			PreparedStatement ps=con.prepareStatement("delete from registered_events where id=? and eventid=?");
			ps.setInt(1,userId);
			ps.setInt(2,m.getId());
			status=ps.executeUpdate();
			ps.close();
		}catch(Exception ex){System.out.println(ex);}
		finally{
			if(con!=null) {
				 try { con.close(); } catch (Exception ex) { }
			}
		}

		return status;
	}
	
	public static List<MarvelCharacters> getAllRegisteredCharacters(int id){
		List<MarvelCharacters> list=new ArrayList<MarvelCharacters>();
		Connection con=getConnection();

		try{
			PreparedStatement ps1=con.prepareStatement("select eventid from registered_events where id = ?");
			ps1.setInt(1, id);
			ResultSet rs1=ps1.executeQuery();
			while(rs1.next()) {
				PreparedStatement ps2=con.prepareStatement("select * from characters where id = ?");
				ps2.setInt(1,rs1.getInt("eventid"));
				ResultSet rs2=ps2.executeQuery();
				while(rs2.next()){
					MarvelCharacters m=new MarvelCharacters();
					m.setId(rs2.getInt("id"));
					m.setcharName(rs2.getString("charName"));
					m.setspeakingDay(rs2.getString("speakingDay"));
					m.setspeakingTime(rs2.getString("speakingTime"));
					m.setroomNum(rs2.getString("roomNum"));
					m.setmovies(rs2.getString("movies"));
					m.setcharacterImage(rs2.getString("characterImage"));
					list.add(m);
				}
				ps2.close();
				rs2.close();
			}
			ps1.close();
			rs1.close();
		}catch(Exception e){System.out.println(e);}
		finally{
			if(con!=null) {
				 try { con.close(); } catch (Exception ex) { }
			}
		}
		return list;
	}
}
