-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: marvelconventiondatabase
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `characters` (
  `id` int NOT NULL,
  `charName` varchar(255) DEFAULT NULL,
  `speakingDay` varchar(255) DEFAULT NULL,
  `speakingTime` varchar(255) DEFAULT NULL,
  `roomNum` varchar(10) DEFAULT NULL,
  `movies` varchar(255) DEFAULT NULL,
  `characterImage` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
INSERT INTO `characters` VALUES (1,'Spider-Man','Day One','9:00-11:00am','101','Spider-Man: Homecoming & Far From Home, Avengers: Infinity War & Endgame, Captain America: Civil War','https://i2.wp.com/www.theilluminerdi.com/wp-content/uploads/2020/01/spiderman.jpg'),(2,'The Falcon','Day One','9:00-11:00am','201','Captain America: The Winter Soldier & Civil War, Avengers: Infinity War & Endgame','https://img.cinemablend.com/filter:scale/quill/3/c/1/2/0/5/3c1205b064eff080658ddccc8a393e11701e9c81.jpg?mw=600'),(3,'Thor','Day One','1:00-3:00pm','101','Thor (1, The Dark World, Ragnorok), Avengers (1, Age of Ultron, Infinity War, Endgame)','https://images-na.ssl-images-amazon.com/images/G/01/digital/video/hero/Movies/2013/ThorDarkWorld_2194942100-TDW0NNG1._V362444527_SX1080_.jpg'),(4,'Black Widow','Day One','1:00-3:00pm','201','Iron Man 2, Avengers (1, Age of Ultron, Infinity War, Endgame), Captian America (The Winter Soldier, Civil War)','https://cdn.vox-cdn.com/thumbor/UG_sp_ns0WcRjPDXs2BhbaMSuAI=/1400x788/filters:format(jpeg)/cdn.vox-cdn.com/uploads/chorus_asset/file/19426690/black_widow_marvel.jpeg'),(5,'Iron Man','Day Two','9:00-11:00am','101','Iron Man (1, 2, 3), Avengers (1, Age of Ultron, Infinity War, Endgame), Captain American: Civil War, Spider-Man: Homecoming','https://images.immediate.co.uk/production/volatile/sites/3/2018/05/IRON-2008-d7a2706.jpg?quality=90&resize=768,574'),(6,'Captain Marvel','Day Two','9:00-11:00am','201','Captain Marvel, Avengers: Endgame','https://img.cinemablend.com/filter:scale/quill/a/2/2/b/d/0/a22bd0b3a8ea873b67f6f228d0bd792f95cdd4c7.jpg?mw=600'),(7,'Dr. Strange','Day Two','1:00-3:00pm','101','Dr. Strange, Avengers: Infinity War & Endgame','https://deadline.com/wp-content/uploads/2016/10/doctor-strange2.jpg?w=640'),(8,'Captain America','Day Two','1:00-3:00pm','201','Captain America: (The First Avenger, The Winter Soldier, Civil War), Avengers: (1, Age of Ultron, Infinity War, Endgame), ','https://cf-images.us-east-1.prod.boltdns.net/v1/static/5359769168001/0a823cb0-01a9-4835-a348-c64187783ccb/d37cb96c-805c-4aa2-9f2f-e62d9eb814c7/1280x720/match/image.jpg'),(9,'TestName2','TestDay2','TestTime2','102','TestMovie2',NULL);
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-15  9:29:33
