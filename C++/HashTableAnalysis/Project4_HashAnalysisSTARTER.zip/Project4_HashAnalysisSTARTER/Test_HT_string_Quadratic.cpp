#pragma once
#include <fstream>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>  
#include "QuadraticProbing.h"
#include "UniformRandom.h" 
using namespace std;

//****************Testing HashTable<string> with Quadratic Probin g****************

void test_HT_string_quadratic(
	ofstream & htAnalysisFile,
	const unsigned NUM_OF_TABLES,
	const unsigned *tableSizes,
	const unsigned MAX_NUM_KEYS,
	const string *arr_keys,
	const string *arrSearchKeys,
	unsigned *initialTotalProbes,
	unsigned *resultSuccessContainsTotalProbes,
	unsigned *resultUnSuccessContainsTotalProbes,
	unsigned *successfulTotal,
	unsigned *unsuccessfulTotal
)
//****************Testing HashTable with Chaining using string keys*****************
{
}

