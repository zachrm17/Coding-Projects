#pragma once
#include <fstream>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>   
#include "SeparateChaining.h"
#include "UniformRandom.h" 
using namespace std;

//****************Testing HashTable<string> with Chaining probing*****************

void test_HT_string_chaining(
	ofstream & htAnalysisFile,
	const unsigned NUM_OF_TABLES,
	const unsigned *tableSizes,
	const unsigned MAX_NUM_KEYS,
	const string *arr_keys,
	const string *arrSearchKeys,
	unsigned *initialTotalProbes,
	unsigned *resultSuccessContainsTotalProbes,
	unsigned *resultUnSuccessContainsTotalProbes,
	unsigned *successfulTotal,
	unsigned *unsuccessfulTotal
)
//****************Testing HashTable<string> with Chaining probing ***************
{


}

